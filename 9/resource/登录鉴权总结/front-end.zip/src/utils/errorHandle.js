const errorHandle = (err) => {
  console.log(err)
}

export default errorHandle
