export default {
  baseUrl: {
    dev: 'http://localhost:3000',
    pro: 'http://www.toimc.com:12000'
  }
}
