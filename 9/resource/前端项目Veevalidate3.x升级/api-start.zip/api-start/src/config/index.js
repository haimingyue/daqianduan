const DB_URL = 'mongodb://test:123456@47.105.212.161:15000/testdb'
const REDIS = {
  host: '47.105.212.161',
  port: 15001,
  password: '123456'
}

export default {
  DB_URL,
  REDIS
}