const DB_URL = 'mongodb://test:123456@47.105.212.161:15000/testdb'
const REDIS = {
  host: '47.105.212.161',
  port: 15001,
  password: '123456'
}
const JWT_SECRET = 'a&*38QthAKuiRwISGLotgq^3%^$zvA3A6Hfr8MF$jM*HY4*dWcwAW&9NGp7*b53!'

export default {
  DB_URL,
  REDIS,
  JWT_SECRET
}