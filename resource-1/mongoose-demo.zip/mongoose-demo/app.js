const mongoose = require('mongoose')

// 定义连接，连接过程 -> DBHelper.js
mongoose.connect('mongodb://test:123456@47.105.212.161:15000/testdb', { useNewUrlParser: true, useUnifiedTopology: true })

// 连接collections，model + schema -> model/test.js
const User = mongoose.model('users', { name: String, age: Number, email: String })

const imooc = new User({
  name: 'imooc-test',
  age: 30,
  email: 'imooc@imooc.com'
})

imooc.save().then(() => { console.log('save Ok!'); })