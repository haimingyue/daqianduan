const DB_URL = 'mongodb://test:123456@47.105.212.161:15000/testdb'

export default {
  DB_URL
}